class InvalidPenalizerConfigError(Exception):
    pass
