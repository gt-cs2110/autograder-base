class InvalidGraderConfigError(Exception):
    pass
